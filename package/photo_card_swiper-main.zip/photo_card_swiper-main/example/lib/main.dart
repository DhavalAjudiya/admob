

import 'package:flutter/material.dart';

import 'example_page_widget.dart';

void main() {
  runApp(MaterialApp(
    home: ExamplePageWidget(),
    debugShowCheckedModeBanner: false,
  ));
}
