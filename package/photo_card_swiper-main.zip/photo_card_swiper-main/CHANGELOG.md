## [0.0.1] - 06 May 2021.

* A simple flutter package for creating a swiping card layout for list of photos.

## [0.0.2] - 07 May 2021.

* Fixed bug for image name path and updated README.md.

## [0.0.3] - 09 May 2021.

* Added Network Image option for card and updated README.md.

## [0.0.4] - 10 June 2021.

* Fixed Network Image option for feedback card and updated README.md.

## [0.0.5] - 03 July 2021.

* Exposed cardId attribute for PhotoCard Model

## [0.0.6] - 08 August 2021.

* Added few more global attributes to customize PhotoSwiper. 
* bool hideTitleText
* bool hideDescriptionText
* BoxFit imageScaleType
* Color imageBackgroundColor
